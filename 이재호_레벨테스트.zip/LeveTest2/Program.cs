﻿
namespace LevelTest2
{
    static internal class Program
    {
        static void Main(string[] args)
        {
            Monster[] monsters = new Monster[5];
            monsters[0] = new Pikachu();
            monsters[1] = new Charmander();
            monsters[2] = new Squirtle();
            monsters[3] = new Bulbasaur();
            monsters[4] = new("털뭉치");

            foreach (Monster monster in monsters)
            {
                
                Console.WriteLine($"{monster.name} 공격해!");
                Monster.Attack();
                Console.WriteLine();
            }

        }
        struct Attack
        {


            public string pikachu;
            public string Charmander;
            public string Squirtle;
            public string Bulbasaur;
        }
        class Monster
        {
            public string name;
            public Attack skill;
            
            public Monster(string name)
            {
                this.name = name;
                
            }

           public virtual void Attack()
           {
               //어택을 실행하면 해당 포켓몬의 공격기술이 나가야함
               Console.WriteLine("스킬");
           }

        }
           class Pikachu : Monster
           {
            
               public Pikachu(string name = "Pikachu") : base(name)
               {
                   this.name = name;
                   this.name = "피카츄";
               }
            public override void Attack()
            {
                Console.WriteLine("백만볼트 !");
            }
            
           }
        
           class Charmander : Monster
           {

            public Charmander(string name = "Charmander") : base(name)
            {
                this.name = name;
                this.name = "파이리";
            }
            public override void Attack()
            {
                Console.WriteLine("화염방사 !");
            }
        }
        
           class Squirtle : Monster
           {

            public Squirtle(string name = "Squirtle") : base(name)
            {
                this.name = name;
                this.name = "꼬부기";
            }
            public override void Attack()
            {
                Console.WriteLine("물총발사 !");
            }
        }
           class Bulbasaur : Monster
           {

            public Bulbasaur(string name = "Bulbasaur") : base(name)
            {
                this.name = name;
                this.name = "이상해씨";
            }
            public override void Attack()
            {
                Console.WriteLine("덩굴채찍 !");
            }
        }
        
    }
}








